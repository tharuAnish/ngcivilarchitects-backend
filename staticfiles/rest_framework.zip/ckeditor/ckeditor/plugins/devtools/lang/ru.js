﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","ru",{title:"Информация об элементе",dialogName:"Имя окна диалога",tabName:"Имя вкладки",elementId:"ID элемента",elementType:"Тип элемента"});